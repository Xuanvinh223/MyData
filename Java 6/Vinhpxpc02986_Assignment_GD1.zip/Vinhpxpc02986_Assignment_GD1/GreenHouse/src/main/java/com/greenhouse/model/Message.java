package com.greenhouse.model;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Message {
    public static String message;
    public static String type;
}
